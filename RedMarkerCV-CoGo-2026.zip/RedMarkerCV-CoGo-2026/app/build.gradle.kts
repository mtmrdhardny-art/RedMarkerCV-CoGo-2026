plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.redmarkercv"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.redmarkercv"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
