package com.example.redmarkercv;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);

        TextView title = new TextView(this);
        title.setText("Red Marker CV");
        title.setTextSize(28);
        title.setTextColor(Color.DKGRAY);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("مشروع الرؤية الحاسوبية\n\nالخطوة الأولى تعمل بنجاح.\nسيتم إضافة التقاط الشاشة واكتشاف اللون الأحمر في المرحلة التالية.");
        info.setTextSize(18);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 30, 0, 0);

        root.addView(title);
        root.addView(info);
        setContentView(root);
    }
}
